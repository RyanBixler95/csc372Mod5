package csc372mod5;

import java.util.Scanner;

public class Recursion {
	
	public static int product(int[] numbers, int index)	{
		if(index == 0)	{
			return numbers[index];
		}
		else	{
			return numbers[index] * product(numbers, index - 1);
		}
	}
	
	public static void main(String[] args)	{
		Scanner scnr = new Scanner(System.in);
		int[] numbers = new int[5];
		
		System.out.println("Enter five numbers (ex: 1 2 3 4 5):");
		for(int i = 0; i < 5; i++)	{
			numbers[i] = scnr.nextInt();
		}
		
		int result = product(numbers, 4); 
		System.out.println("The product of the entered numbers is: " + result);
		scnr.close();
	}
}